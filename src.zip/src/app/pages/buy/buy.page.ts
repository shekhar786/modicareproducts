import { Component, OnInit } from '@angular/core';
import firebase from 'firebase';
import { FIREBASE_CREDENTIALS } from '../../firebase.credentials';
@Component({
  selector: 'app-buy',
  templateUrl: './buy.page.html',
  styleUrls: ['./buy.page.scss'],
})
export class BuyPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  submit = () => {
   
    if(this.name && this.pin && this.address && this.state && this.mobile){
      firebase.initializeApp(FIREBASE_CREDENTIALS);
      //var db = firebase.firestore();
      firebase.database().ref('buying').push({
      "productName" : this.name,
      "pinCode" : this.pin,
      "address" : this.address,
      "state" : this.state,
      "mobile" : this.mobile
      })
      alert("data received you will receive call shortly")
    }
    else {
      alert("please enter valid details")
    }
  }

}
