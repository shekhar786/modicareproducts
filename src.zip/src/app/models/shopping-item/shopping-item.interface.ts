export interface ShoppingItem {
    $key?: string,
    itemName: string;
    itemNumber : number;
}