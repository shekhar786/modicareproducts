export const FIREBASE_CREDENTIALS = {
  apiKey: "AIzaSyDwVH-Gekgv1dtblk2sECaqyruznoJ4KtI",
    authDomain: "pushtest-166314.firebaseapp.com",
    databaseURL: "https://pushtest-166314.firebaseio.com",
    projectId: "pushtest-166314",
    storageBucket: "pushtest-166314.appspot.com",
    messagingSenderId: "717173261570",
    appId: "1:717173261570:web:b062480f06c00821c6ae1b"
  };